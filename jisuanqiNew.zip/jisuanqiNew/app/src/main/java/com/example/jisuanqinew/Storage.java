package com.example.jisuanqinew;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import java.util.List;
import java.util.Stack;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.List;
import java.util.StringTokenizer;

public class Storage extends ViewModel {
    private MutableLiveData<String> mainNum;//主数据
    private MutableLiveData<String> huansuannum;
    List<String> items;

    public double pi=4*Math.atan(1);
    public boolean havePoint = false;
    public String judgeSign="";
    public String sign2="";
    public String sign3="";
    public String signfuhao="",signteshujisuan="";
    public String num[] = {""};

    public MutableLiveData<String> getMainNum(){
        if (mainNum == null) {
            mainNum = new MutableLiveData<>();
            mainNum.setValue("0");
        }
        return mainNum;
    }

    public MutableLiveData<String> getHuansuan(){
        if (huansuannum ==null ){
            huansuannum = new MutableLiveData<>();
            huansuannum.setValue("0");
        }
        return huansuannum;
    }

    public void setHuansuannum(String n) {
        if (huansuannum.getValue().equals("0")) {
            huansuannum.setValue(n);
        } else {
            huansuannum.setValue(huansuannum.getValue() + n);
        }
    }

    public void setMainNum(String n) {
        if (mainNum.getValue().equals("0")) {
            mainNum.setValue(n);
        } else {
            mainNum.setValue(mainNum.getValue() + n);
        }
    }

    private List<String> putStrToList(String expression) {
        char[] chars = expression.toCharArray();
        int len = chars.length;
        List<String> items = new ArrayList<>(len);
        int index = 0;
        while (index < len) {
            char c = chars[index];
            //数字
            if (c >= 48 && c <= 57) {
                String tmp = "";
                //操作数大于一位数，主要是通过判断下一位是否为数字
                while (index < chars.length && chars[index] >= 48 && chars[index] <= 57) {
                    tmp += chars[index];
                    index++;
                }
                items.add(tmp);
            } else {
                items.add(c + "");
                index++;
            }
        }
        return items;
    }
    /**
     * 将表达式的操作数和运算符转换成集合
     */
    public List<String> midfixToSuffix(String expr) {
        List<String> items = putStrToList(expr);//操作数栈
        Stack<String> operateStack = new Stack<>();//临时变量的保存集合，这里使用了List集合//如果用栈也可以实现，但是需要在最后将弹出栈元素的逆序进行运算//所以使用List集合避免了这个转换的问题
        List<String> tmp = new ArrayList<>();
        int index = 0;//操作的位置
        int len = items.size();//表达式长度
        while (index < len) {
            String item = items.get(index);
            if (item.matches("\\d+")) {//遇到操作数0-9时 '\d'表示数字0-9，将其压tmp；
                tmp.add(item);
            } else if (item.equals("(")) {//如果是左括号“(”，则直接压入operateStack
                operateStack.push(item);
            } else if (item.equals(")")) {//如果是右括号“)”，则依次弹出operateStack栈顶的运算符，并压入tmp，直到遇到左括号为止，此时将这一对括号丢弃
                while (!operateStack.peek().equals("(")) { tmp.add(operateStack.pop()); }
                operateStack.pop();//直接弹出栈顶元素即可
            }  else {//遇到运算符时，比较其与operateStack栈顶运算符的优先级
                if (operateStack.isEmpty() || "(".equals(operateStack.peek())) {//如果operateStack为空，或栈顶运算符为左括号“(”，则直接将此运算符入栈；
                    operateStack.push(item);
                } else if (priority(item) > priority(operateStack.peek())) {//否则，若优先级比栈顶运算符的高，也将运算符压入operateStack；
                    operateStack.push(item);
                } else {//否则，将operateStack栈顶的运算符弹出并压入到tmp中，再次转到(4-1)与operateStack中新的栈顶运算符相比较；
                    while (!operateStack.isEmpty() && priority(item) <= priority(operateStack.peek())) { tmp.add(operateStack.pop()); }
                    operateStack.push(item);//将运算符压入栈
                }
            }
            index++;//没一轮结束需要将操作位置往后移动一位
        }
        while (!operateStack.isEmpty()) {//解析结束后需要将剩下的栈元素全部弹出来放入到tmp中
            tmp.add(operateStack.pop());
        }
        return tmp;
    }


    /*
     * 判断特殊符号，并计算，返回String类型
     */
    public String judgeTeshufuhao() {
        String value = "0";
        switch (judgeSign) {
            case "log":
                value = String.valueOf(Math.log(Double.valueOf(mainNum.getValue())));
                break;
            case "square"://平方完成
                value = String.valueOf(Double.valueOf(mainNum.getValue())*Double.valueOf(mainNum.getValue()));
                break;
            case "!":
                value =String.valueOf(factorial(Double.valueOf(mainNum.getValue())));
                break;
            case "sqrt":
                value = String.valueOf(Math.sqrt(Double.valueOf(mainNum.getValue())));
                break;
            case "1/x":
                value = String.valueOf(1/(Double.valueOf(mainNum.getValue())));
                break;
            case"sin":
                value = String.valueOf(Math.sin(Double.valueOf(mainNum.getValue())));
                break;
            case "cos":
                value = String.valueOf(Math.cos(Double.valueOf(mainNum.getValue())));
                break;
            case "tan":
                value = String.valueOf(Math.tan(Double.valueOf(mainNum.getValue())));
        }
        return value;
    }


    public static double factorial(double number) {
        if (number <= 1)
            return 1;
        else
            return number * factorial(number - 1);
    }



    /**
     * 获取运算符的优先级，数字越大优先级越大
     *
     * @param operateChar 运算符
     * @return 优先级
     */
    private int priority(String operateChar) {
        if ("*".equals(operateChar) || "/".equals(operateChar)) {
            return 2;
        } else if ("+".equals(operateChar) || "-".equals(operateChar)) {
            return 1;
        }else if(".".equals(operateChar)){
            return 3;
        }
        else {
            //throw new RuntimeException("非法的操作符：" + operateChar);
            return 0;
        }
    }


    /**
     * 用于保存过程变量和操作符等
     */
    public Double calculate(List<String> items) {
        Stack<String> stack = new Stack<>();
        for (int i=0;i<items.size();i++) {
            String item = items.get(i);
            // 正则取出数字
            if (item.matches("\\d+")) { // 匹配的是多位数
                 stack.push(item);
            } else {// pop出两个数 并且运算 在入栈
                double num2 = Double.parseDouble(stack.pop());
                double num1;
                if (item.equals(".")){
                    String front = stack.pop();
                    String behind = String.valueOf((Math.round(num2)));
                    String num = front+"."+behind;
                    num1=Double.parseDouble(num);
                    stack.push(String.valueOf(num1));
                    continue; }
                else { num1 = Double.parseDouble(stack.pop()); }
                double res;
                if ("+".equals(item)) { res = num1 + num2; }
                else if ("-".equals(item)) { res = num1 - num2; }
                else if ("*".equals(item)) { res = num1 * num2; }
                else if ("/".equals(item)) { res = num1 / num2; }
                else { throw new RuntimeException("运算符错误"); }
                stack.push("" + res);
            }
        }
        return Double.parseDouble(stack.pop());
    }

    public String huansuan() {
        String value = "0";

        if (sign2 == "0") {
            switch (sign3) {
                case "0":
                    value = String.valueOf(Double.valueOf(mainNum.getValue()));
                    break;

                case "1":
                    value = String.valueOf(Double.valueOf(mainNum.getValue()) / 10);
                    break;
                case "2":
                    double d = Double.valueOf(mainNum.getValue());
                    value = String.valueOf(d / 100);
                    break;
                case "3":
                    double dy = Double.valueOf(mainNum.getValue());
                    value = String.valueOf(dy / 1000000);
                    break;
                case "4":
                    double dx = Double.valueOf(mainNum.getValue());
                    value = String.valueOf(dx / 1000);
                    break;
                case "5":
                    double dz = Double.valueOf(mainNum.getValue());
                    value = String.valueOf(dz / 1000 * 0.0032808);


            }
        }


        return value;
    }

}
