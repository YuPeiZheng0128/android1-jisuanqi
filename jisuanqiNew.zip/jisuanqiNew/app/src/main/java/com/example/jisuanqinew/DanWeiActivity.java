package com.example.jisuanqinew;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuPopupHelper;

import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;

public class DanWeiActivity extends AppCompatActivity{
    private TextView changduT1,changduT2,areaT1,areaT2,temT1,temT2,VT1,VT2;
    private Button btnBack,btnLChange,btnAChange,btnTChange,btnVChange;
    private EditText LEt1,LEt2,AEt1,AEt2,TEt1,TEt2,VEt1,VEt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dan_wei);

        btnBack = findViewById(R.id.back);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        changduT1 = findViewById(R.id.lInputDW);
        changduT1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(DanWeiActivity.this,changduT1);//创建mennu
                popupMenu.getMenuInflater().inflate(R.menu.main,popupMenu.getMenu());//加载菜单资源
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {//菜单监听
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.nami:
                                changduT1.setText("纳米");break;
                            case R.id.fenmi:
                                changduT1.setText("分米");break;
                            case R.id.limi:
                                changduT1.setText("厘米");break;
                            case R.id.haomi:
                                changduT1.setText("毫米");break;
                            case R.id.mi:
                                changduT1.setText("米");break;
                            case R.id.km:
                                changduT1.setText("千米");break;
                            case R.id.weimi:
                                changduT1.setText("微米");break;
                        }return true;
                    }
                });
                try {
                    Field field = popupMenu.getClass().getDeclaredField("mm");
                    field.setAccessible(true);
                    MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
                popupMenu.show();
            }
        });

        changduT2 = findViewById(R.id.lOutputDW);
        changduT2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(DanWeiActivity.this,changduT2);
                popupMenu.getMenuInflater().inflate(R.menu.main,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.nami:
                                changduT2.setText("纳米");break;
                            case R.id.fenmi:
                                changduT2.setText("分米");break;
                            case R.id.limi:
                                changduT2.setText("厘米");break;
                            case R.id.haomi:
                                changduT2.setText("毫米");break;
                            case R.id.mi:
                                changduT2.setText("米");break;
                            case R.id.km:
                                changduT2.setText("公里");break;
                        }
                        return true;
                    }
                });

                try {
                    Field field = popupMenu.getClass().getDeclaredField("mm");
                    field.setAccessible(true);
                    MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
                popupMenu.show();
            }
        });

        LEt1=findViewById(R.id.lEt1);
        LEt2=findViewById(R.id.lEt2);
        btnLChange = findViewById(R.id.changebtnL);
        btnLChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String unit1 = (String) changduT1.getText();
                String unit2 = (String) changduT2.getText();

                String number= (String)LEt1.getText().toString();
                ChangeUnit LCU = new ChangeUnit();
                LEt2.setText(String.valueOf(LCU.ChangetoUnit(unit1,number,unit2)));
            }
        });

        areaT1 = findViewById(R.id.aInputDW);
        areaT1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(DanWeiActivity.this,areaT1);
                popupMenu.getMenuInflater().inflate(R.menu.amain,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.pfmaomi:
                                areaT1.setText("平方毫米");break;
                            case R.id.pffenmi:
                                areaT1.setText("平方分米");break;
                            case R.id.pflimi:
                                areaT1.setText("平方厘米");break;
                            case R.id.gongqing:
                                areaT1.setText("公顷");break;
                            case R.id.gongmu:
                                areaT1.setText("公亩");break;
                            case R.id.pfmi:
                                areaT1.setText("平方米");break;
                            case R.id.pfkm:
                                areaT1.setText("平方千米");break;
                        }
                        return true;
                    }
                });

                try {
                    Field field = popupMenu.getClass().getDeclaredField("mm");
                    field.setAccessible(true);
                    MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
                popupMenu.show();
            }
        });

        areaT2 = findViewById(R.id.aOutputDW);
        areaT2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建mennu
                PopupMenu popupMenu = new PopupMenu(DanWeiActivity.this,areaT2);
                //加载菜单资源
                popupMenu.getMenuInflater().inflate(R.menu.amain,popupMenu.getMenu());

                //菜单监听
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.pfmaomi:
                                areaT2.setText("平方毫米");
                                break;
                            case R.id.pffenmi:
                                areaT2.setText("平方分米");
                                break;
                            case R.id.pflimi:
                                areaT2.setText("平方厘米");
                                break;
                            case R.id.gongqing:
                                areaT2.setText("公顷");
                                break;
                            case R.id.gongmu:
                                areaT2.setText("公亩");
                                break;
                            case R.id.pfmi:
                                areaT2.setText("平方米");
                                break;
                            case R.id.pfkm:
                                areaT2.setText("平方千米");
                                break;
                        }
                        return true;
                    }
                });

                try {
                    Field field = popupMenu.getClass().getDeclaredField("mm");
                    field.setAccessible(true);
                    MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
                popupMenu.show();
            }
        });

        AEt1=findViewById(R.id.aEt1);
        AEt2=findViewById(R.id.aEt2);
        btnAChange = findViewById(R.id.changebtnA);
        btnAChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String unit1 = (String) areaT1.getText();
                String unit2 = (String) areaT2.getText();

                String number= (String)AEt1.getText().toString();
                ChangeUnit LCU = new ChangeUnit();
                AEt2.setText(String.valueOf(LCU.ChangetoUnitarea(unit1,number,unit2)));
            }
        });

        temT1 = findViewById(R.id.tInputDW);
        temT1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建mennu
                PopupMenu popupMenu = new PopupMenu(DanWeiActivity.this,temT1);
                //加载菜单资源
                popupMenu.getMenuInflater().inflate(R.menu.tmain,popupMenu.getMenu());

                //菜单监听
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.sheshidu:
                                temT1.setText("摄氏度");
                                break;
                            case R.id.huashidu:
                                temT1.setText("华氏度");
                                break;
                            case R.id.kaierwen:
                                temT1.setText("开尔文");
                                break;
                        }
                        return true;
                    }
                });

                try {
                    Field field = popupMenu.getClass().getDeclaredField("mm");
                    field.setAccessible(true);
                    MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
                popupMenu.show();
            }
        });

        temT2 = findViewById(R.id.tOutputDW);
        temT2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建mennu
                PopupMenu popupMenu = new PopupMenu(DanWeiActivity.this,temT2);
                //加载菜单资源
                popupMenu.getMenuInflater().inflate(R.menu.tmain,popupMenu.getMenu());

                //菜单监听
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.sheshidu:
                                temT2.setText("摄氏度");
                                break;
                            case R.id.huashidu:
                                temT2.setText("华氏度");
                                break;
                            case R.id.kaierwen:
                                temT2.setText("开尔文");
                                break;
                        }
                        return true;
                    }
                });

                try {
                    Field field = popupMenu.getClass().getDeclaredField("mm");
                    field.setAccessible(true);
                    MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
                popupMenu.show();
            }
        });

        TEt1=findViewById(R.id.tEt1);
        TEt2=findViewById(R.id.tEt2);
        btnTChange = findViewById(R.id.changebtnT);
        btnTChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String unit1 = (String) temT1.getText();
                String unit2 = (String) temT2.getText();

                String number= (String)TEt1.getText().toString();
                ChangeUnit LCU = new ChangeUnit();
                TEt2.setText(String.valueOf(LCU.ChangetoUnittemperature(unit1,number,unit2)));
            }
        });

        VT1 = findViewById(R.id.vInputDW);
        VT1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建mennu
                PopupMenu popupMenu = new PopupMenu(DanWeiActivity.this,VT1);
                //加载菜单资源
                popupMenu.getMenuInflater().inflate(R.menu.vmain,popupMenu.getMenu());

                //菜单监听
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.lfmaomi:
                                VT1.setText("立方毫米");break;
                            case R.id.lffenmi:
                                VT1.setText("立方分米");break;
                            case R.id.lflimi:
                                VT1.setText("立方厘米");break;
                            case R.id.lfmi:
                                VT1.setText("立方米");break;
                            case R.id.lfkm:
                                VT1.setText("立方千米");break;
                        }
                        return true;
                    }
                });

                try {
                    Field field = popupMenu.getClass().getDeclaredField("mm");
                    field.setAccessible(true);
                    MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
                popupMenu.show();
            }
        });

        VT2 = findViewById(R.id.vOutputDW);
        VT2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建mennu
                PopupMenu popupMenu = new PopupMenu(DanWeiActivity.this,VT2);
                //加载菜单资源
                popupMenu.getMenuInflater().inflate(R.menu.vmain,popupMenu.getMenu());

                //菜单监听
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.lfmaomi:
                                VT2.setText("立方毫米");
                                break;
                            case R.id.lffenmi:
                                VT2.setText("立方分米");
                                break;
                            case R.id.lflimi:
                                VT2.setText("立方厘米");
                                break;
                            case R.id.lfmi:
                                VT2.setText("立方米");
                                break;
                            case R.id.lfkm:
                                VT2.setText("立方千米");
                                break;
                        }
                        return true;
                    }
                });

                try {
                    Field field = popupMenu.getClass().getDeclaredField("mm");
                    field.setAccessible(true);
                    MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
                popupMenu.show();
            }
        });

        VEt1=findViewById(R.id.vEt1);
        VEt2=findViewById(R.id.vEt2);
        btnVChange = findViewById(R.id.changebtnV);
        btnVChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String unit1 = (String) VT1.getText();
                String unit2 = (String) VT2.getText();

                String number= (String)VEt1.getText().toString();
                ChangeUnit LCU = new ChangeUnit();
                VEt2.setText(String.valueOf(LCU.ChangetoUnitvolume(unit1,number,unit2)));
            }
        });

    }


}