package com.example.jisuanqinew;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.List;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button bt_num0, bt_num1, bt_num2, bt_num3, bt_num4, bt_num5, bt_num6, bt_num7,
            bt_num8, bt_num9, bt_delete, bt_sub, bt_add, bt_div, bt_mul, bt_equal, bt_point, bt_clear,bt_pai, bt_log,
            bt_ds, bt_factorial, bt_sin, bt_cos, bt_tan, bt_left, bt_right, bt_square, bt_sqrt,bt_jinzhi,bt_danwei,bt_caidan;
    private EditText et_calc;
    private Storage myStorage;
    List<String> items;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myStorage = new ViewModelProvider(this,new ViewModelProvider.NewInstanceFactory()).get(Storage.class);
        myStorage.getMainNum().observe(this, new Observer<String>() {
                    @Override
                    public void onChanged(String s) {
                        et_calc.setText(myStorage.getMainNum().getValue());


                        if (myStorage.signteshujisuan.equals("")) {
                            et_calc.setText(myStorage.getMainNum().getValue());
                        } else {

                        }

                    }
                });



        try {
            bt_caidan= (Button) findViewById(R.id.menu);
            bt_caidan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //创建mennu
                    PopupMenu popupMenu = new PopupMenu(MainActivity.this,view);
                    //加载菜单资源
                    popupMenu.getMenuInflater().inflate(R.menu.cmain,popupMenu.getMenu());

                    //菜单监听
                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem menuItem) {
                            switch (menuItem.getItemId()){
                                case R.id.help:
                                    Toast.makeText(MainActivity.this, "这是帮助", Toast.LENGTH_LONG).show();
                                    break;
                                case R.id.exit:
                                    System.exit(0);
                                    break;
                            }
                            return true;
                        }
                    });

                    try {
                        Field field = popupMenu.getClass().getDeclaredField("mm");
                        field.setAccessible(true);
                        MenuPopupHelper menuPopupHelper = (MenuPopupHelper) field.get(popupMenu);
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace();
                    }
                    popupMenu.show();
                }

            });

            bt_danwei= (Button) findViewById(R.id.danwei);
            bt_danwei.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(MainActivity.this,DanWeiActivity.class);
                    startActivityForResult(intent,0);
                }
            });
            bt_jinzhi= (Button) findViewById(R.id.jinzhi);
            bt_jinzhi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(MainActivity.this,JinZhiActivity2.class);
                    startActivityForResult(intent,0);
                }
            });
        } catch (Exception e) {

        }


        Configuration mConfiguration = this.getResources().getConfiguration();
        //获取屏幕方向
        int ori = mConfiguration.orientation;
        if (ori == mConfiguration.ORIENTATION_LANDSCAPE) {

            getSupportActionBar().hide();//隐藏标题
            //横屏
        } else if (ori == mConfiguration.ORIENTATION_PORTRAIT) {

            //竖屏
        }
        initViewAndListener();
    }

    private void initViewAndListener() {


        bt_num0 = (Button) findViewById(R.id.num0);
        bt_num0.setOnClickListener(this);

        bt_num1 = (Button) findViewById(R.id.num1);
        bt_num1.setOnClickListener(this);


        bt_num2 = (Button) findViewById(R.id.num2);
        bt_num2.setOnClickListener(this);

        bt_num3 = (Button) findViewById(R.id.num3);
        bt_num3.setOnClickListener(this);

        bt_num4 = (Button) findViewById(R.id.num4);
        bt_num4.setOnClickListener(this);

        bt_num5 = (Button) findViewById(R.id.num5);
        bt_num5.setOnClickListener(this);

        bt_num6 = (Button) findViewById(R.id.num6);
        bt_num6.setOnClickListener(this);

        bt_num7 = (Button) findViewById(R.id.num7);
        bt_num7.setOnClickListener(this);

        bt_num8 = (Button) findViewById(R.id.num8);
        bt_num8.setOnClickListener(this);

        bt_num9 = (Button) findViewById(R.id.num9);
        bt_num9.setOnClickListener(this);

        bt_delete = (Button) findViewById(R.id.delete);
        bt_delete.setOnClickListener(this);

        bt_div = (Button) findViewById(R.id.div);
        bt_div.setOnClickListener(this);

        bt_mul = (Button) findViewById(R.id.mul);
        bt_mul.setOnClickListener(this);

        bt_sub = (Button) findViewById(R.id.sub);
        bt_sub.setOnClickListener(this);

        bt_add = (Button) findViewById(R.id.add);
        bt_add.setOnClickListener(this);

        bt_equal = (Button) findViewById(R.id.result);
        bt_equal.setOnClickListener(this);

        et_calc = (EditText) findViewById(R.id.et_calc);

        bt_point = (Button) findViewById(R.id.point);
        bt_point.setOnClickListener(this);

        bt_clear = (Button) findViewById(R.id.clear);
        bt_clear.setOnClickListener(this);

        bt_pai = (Button) findViewById(R.id.pai);
        bt_pai.setOnClickListener(this);


        try {
            bt_log = (Button) findViewById(R.id.log);
            bt_log.setOnClickListener(this);

            bt_ds = (Button) findViewById(R.id.ds);
            bt_ds.setOnClickListener(this);

            bt_factorial = (Button) findViewById(R.id.factorial);
            bt_factorial.setOnClickListener(this);

            bt_sqrt = (Button) findViewById(R.id.sqrt);
            bt_sqrt.setOnClickListener(this);

            bt_square = (Button) findViewById(R.id.square);
            bt_square.setOnClickListener(this);

            bt_sin = (Button) findViewById(R.id.sin);
            bt_sin.setOnClickListener(this);

            bt_cos = (Button) findViewById(R.id.cos);
            bt_cos.setOnClickListener(this);

            bt_tan = (Button) findViewById(R.id.tan);
            bt_tan.setOnClickListener(this);

            bt_left = (Button) findViewById(R.id.left);
            bt_left.setOnClickListener(this);

            bt_right = (Button) findViewById(R.id.right);
            bt_right.setOnClickListener(this);




        } catch (Exception e) {

        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.num0:
                myStorage.setMainNum("0");
                break;
            case R.id.num1:
                myStorage.setMainNum("1");
                break;
            case R.id.num2:
                myStorage.setMainNum("2");
                break;
            case R.id.num3:
                myStorage.setMainNum("3");
                break;
            case R.id.num4:
                myStorage.setMainNum("4");
                break;
            case R.id.num5:
                myStorage.setMainNum("5");
                break;
            case R.id.num6:
                myStorage.setMainNum("6");
                break;
            case R.id.num7:
                myStorage.setMainNum("7");
                break;
            case R.id.num8:
                myStorage.setMainNum("8");
                break;
            case R.id.num9:
                myStorage.setMainNum("9");
                break;
            case R.id.point:
                myStorage.getMainNum().setValue(myStorage.getMainNum().getValue() + ".");
                break;
            case R.id.right:
                myStorage.setMainNum(")");
                break;
            case R.id.left:
                myStorage.setMainNum("(");
                break;
            case R.id.add:
                myStorage.setMainNum("+");
                break;
            case R.id.sub:
                myStorage.setMainNum("-");
                break;
            case R.id.mul:
                myStorage.setMainNum("*");
                break;
            case R.id.div:
                myStorage.setMainNum("/");
                break;
            case R.id.result:
                if (myStorage.signteshujisuan.equals("")){
                    items = myStorage.midfixToSuffix(myStorage.getMainNum().getValue());
                    double result = myStorage.calculate(items);
                    myStorage.getMainNum().setValue(String.valueOf(result));
                }else {
                    myStorage.judgeSign = "x^y";
                    myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                }
                break;
            case R.id.pai:
                myStorage.setMainNum(String.valueOf(4*Math.atan(1)));
                break;
            case R.id.clear:
                myStorage.signfuhao = "";
                myStorage.getMainNum().setValue("0");
                break;
            case R.id.delete:
                if (!myStorage.getMainNum().getValue().equals("0")) {
                    myStorage.getMainNum().setValue(myStorage.getMainNum().getValue().substring(0, myStorage.getMainNum().getValue().length() - 1));
                    //截取str中从beginIndex开始至endIndex结束时的字符串，并将其赋值给str;
                    if (myStorage.getMainNum().getValue().equals(""))
                        myStorage.getMainNum().setValue("0");
                }
                break;
            case R.id.sin:
                myStorage.judgeSign="sin";
                myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                break;
            case R.id.cos:
                myStorage.judgeSign="cos";
                myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                break;
            case R.id.tan:
                myStorage.judgeSign="tan";
                myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                break;
            case R.id.sqrt:
                myStorage.judgeSign="sqrt";
                myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                break;
            case R.id.square:
                myStorage.judgeSign="square";
                myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                break;
            case R.id.log:
                myStorage.judgeSign="log";
                myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                break;
            case R.id.ds:
                myStorage.judgeSign="1/x";
                myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                break;
            case R.id.factorial:
                myStorage.judgeSign="!";
                myStorage.getMainNum().setValue(myStorage.judgeTeshufuhao());
                break;

        }
    }
}