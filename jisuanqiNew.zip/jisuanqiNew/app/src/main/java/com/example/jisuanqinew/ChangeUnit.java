package com.example.jisuanqinew;


public class ChangeUnit {
	private float temp,metre,result;
	public float ChangetoUnit(String unit,String number,String unit2){
		if (unit.equals("纳米")) {
			temp=Float.valueOf(number);metre = temp/1000000000;
		} else if(unit.equals("微米")){
			temp=Float.valueOf(number);metre = temp/1000000;
		}else if (unit.equals("毫米")) {
			temp=Float.valueOf(number);metre = temp/1000;
		}else if (unit.equals("厘米")) {
			temp=Float.valueOf(number);metre = temp/100;
		}else if (unit.equals("分米")) {
			temp=Float.valueOf(number);metre = temp/10;
		}else if (unit.equals("米")) {
			temp=Float.valueOf(number);metre = temp;
		}else if (unit.equals("公里")) {
			temp=Float.valueOf(number);metre = temp*1000;
		}
		if (unit2.equals("纳米")) {
			result = metre*1000000000;return result;
		} else if(unit2.equals("微米")){
			result = metre*1000000;return result;
		}else if (unit2.equals("毫米")) {
			result = metre*1000;return result;
		}else if (unit2.equals("厘米")) {
			result = metre*100;return result;
		}else if (unit2.equals("分米")) {
			result = metre*10;return result;
		}else if (unit2.equals("米")) {
			result = metre*1;return result;
		}else if (unit2.equals("公里")) {
			result = metre/1000;return result;
		}
		return (Float) null;


	}
	public float ChangetoUnitarea(String unit,String number,String unit2){
		if (unit.equals("平方毫米")) {
			temp=Float.valueOf(number);metre = temp/1000000;
		} else if(unit.equals("平方厘米")){
			temp=Float.valueOf(number);metre = temp/10000;
		}else if (unit.equals("平方分米")) {
			temp=Float.valueOf(number);metre = temp/100;
		}else if (unit.equals("平方米")) {
			temp=Float.valueOf(number);metre = temp/1;
		}else if (unit.equals("公亩")) {
			temp=Float.valueOf(number);metre = temp*100;
		}else if (unit.equals("公顷")) {
			temp=Float.valueOf(number);metre = temp*10000;
		}else if (unit.equals("平方千米")) {
			temp=Float.valueOf(number);metre = temp*100000;
		}if (unit2.equals("平方厘米")) {
			result = metre*10000;return result;
		} else if(unit2.equals("平方分米")){
			result = metre*100;return result;
		}else if (unit2.equals("平方米")) {
			result = metre;return result;
		}else if (unit2.equals("公亩")) {
			result = metre/100;return result;
		}else if (unit2.equals("公顷")) {
			result = metre/10000;return result;
		}else if (unit2.equals("平方千米")) {
			result = metre/1000000;return result;
		}else if (unit2.equals("平方毫米")) {
			result = metre*1000000;return result;
		}
		return (Float) null;
	}
	public float ChangetoUnitvolume(String unit,String number,String unit2){
		if (unit.equals("立方千米")) {
			temp=Float.valueOf(number);metre = temp*1000000000;
		} else if(unit.equals("立方米")){
			temp=Float.valueOf(number);metre = temp;
		}else if (unit.equals("立方分米")) {
			temp=Float.valueOf(number);metre = temp/1000;
		}else if (unit.equals("立方厘米")) {
			temp=Float.valueOf(number);metre = temp/1000000;
		}else if (unit.equals("立方毫米")) {
			temp=Float.valueOf(number);metre = temp/1000000000;
		}
		if (unit2.equals("立方千米")) {
			result = metre/1000000000;return result;
		} else if(unit2.equals("立方分米")){
			result = metre*1000;return result;
		}else if (unit2.equals("立方米")) {
			result = metre;return result;
		}else if (unit2.equals("立方毫米")) {
			result = metre*1000000000;return result;
		}else if (unit2.equals("立方厘米")) {
			result = metre*1000000;return result;
		}
		return (Float) null;
	}
	public float ChangetoUnittemperature(String unit,String number,String unit2){

		if (unit.equals("摄氏度")) {
			temp=Float.valueOf(number);
			metre = (float) (temp+272.15);
		} else if(unit.equals("华氏度")){
			temp=Float.valueOf(number);
			metre = (float) (temp+457.87);
		}else if (unit.equals("开尔文")) {
			temp=Float.valueOf(number);
			metre = temp;
		}
		if (unit2.equals("摄氏度")) {
			result = (float) (metre-272.15);
			return result;
		} else if(unit2.equals("华氏度")){
			result = (float) (metre-457.87);
			return result;
		}else if (unit2.equals("开尔文")) {
			result = metre;
			return result;
		}
		return (Float) null;
	}
}
