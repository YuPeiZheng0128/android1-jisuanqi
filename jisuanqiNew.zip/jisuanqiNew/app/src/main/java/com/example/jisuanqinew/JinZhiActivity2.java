package com.example.jisuanqinew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import java.util.List;
import java.util.Stack;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.List;
import java.util.StringTokenizer;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class JinZhiActivity2 extends AppCompatActivity {

    private Button bt_back;

    private EditText et_Binary;
    private EditText et_Octal;
    private EditText et_Decimal;
    private EditText et_Hex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jin_zhi2);

        Button converse = findViewById(R.id.convert);
        Button clear = findViewById(R.id.clear);
        et_Binary = findViewById(R.id.edBinarySystem);
        et_Octal = findViewById(R.id.edOctalSystem);
        et_Decimal = findViewById(R.id.edDecimalSystem);
        et_Hex = findViewById(R.id.edHexSystem);

        converse.setOnClickListener(view -> onClickConvert());
        clear.setOnClickListener(view -> onClickClear());

        bt_back = findViewById(R.id.fanhui);
        bt_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    @SuppressLint("SetTextI18n")
    private void onClickConvert() {
        String binary = et_Binary.getText().toString();
        String octal = et_Octal.getText().toString();
        String decimal = et_Decimal.getText().toString();
        String hex = et_Hex.getText().toString();

        if (!binary.equals("")) {
            int _binary = Integer.valueOf(binary,2);
            et_Octal.setText(Integer.toOctalString(_binary));
            et_Decimal.setText("" + _binary);
            et_Hex.setText(Integer.toHexString(_binary));
        } else if (!octal.equals("")) {
            int _octal = Integer.valueOf(octal,8);
            et_Binary.setText(Integer.toBinaryString(_octal));
            et_Decimal.setText("" + _octal);
            et_Hex.setText(Integer.toHexString(_octal));
        } else if (!decimal.equals("")) {
            et_Binary.setText(Integer.toBinaryString(Integer.parseInt(decimal)));
            et_Octal.setText(Integer.toOctalString(Integer.parseInt(decimal)));
            et_Hex.setText(Integer.toHexString(Integer.parseInt(decimal)));
        } else if (!hex.equals("")) {
            int _hex = Integer.valueOf(hex,16);
            et_Binary.setText(Integer.toBinaryString(_hex));
            et_Octal.setText(Integer.toOctalString(_hex));
            et_Decimal.setText("" + _hex);
        } else {
            Toast.makeText(JinZhiActivity2.this,"输入为空",Toast.LENGTH_LONG);
        }

    }

    private void onClickClear(){
        et_Binary.setText("");
        et_Octal.setText("");
        et_Decimal.setText("");
        et_Hex.setText("");
    }


}